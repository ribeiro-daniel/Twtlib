from setuptools import setup

setup(
    name="twtlib",
    version="1.0.0",
    author="Daniel Ribeiro",
    author_email="",
    packages=["twtlib"],
    description="Lib to search and post on Twitter",
    long_description="Lib to search and post on Twitter",
    url="https://github.com/ribeiro-daniel/Twtlib",
    license="MIT",
    keywords="Search and Post on Twitter, Buscar e Postar no Twitter"
)

